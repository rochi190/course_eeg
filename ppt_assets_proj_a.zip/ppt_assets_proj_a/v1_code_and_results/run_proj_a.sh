#!/usr/bin/env bash
set -euo pipefail

SESSION="eeg-a"
CFG="/tmp/colab_a_sessions.json"
PROJ_DIR="/home/neil/course_eeg/proj_a_eegdenoise"
RUNNER="/home/neil/course_eeg/run_remote_cmds.py"
DONE_FILE="$PROJ_DIR/.DONE"
FAIL_FILE="$PROJ_DIR/.FAILED"

rm -f "$DONE_FILE" "$FAIL_FILE" "$CFG" "${CFG}.lock"

cleanup() {
    local rc=$?
    echo "[cleanup] Stopping Colab session '$SESSION' (exit=$rc)..."
    colab --config "$CFG" stop -s "$SESSION" >/dev/null 2>&1 || true
    rm -f "$CFG" "${CFG}.lock" /tmp/proj_a_src.tar.gz /tmp/proj_a_outputs.tar.gz
    if [ "$rc" -eq 0 ] && [ -f "$DONE_FILE" ]; then
        echo "[status] SPEC A COMPLETED SUCCESSFULLY"
    else
        touch "$FAIL_FILE"
        echo "[status] SPEC A FAILED (rc=$rc)"
    fi
}
trap cleanup EXIT

echo "[start] SPEC A pipeline started at $(date -Is)"

GPU_TYPE="L4"
if ! timeout 90 colab --config "$CFG" new -s "$SESSION" --gpu L4; then
    echo "[warn] L4 allocation failed/timed out (400/503); cleaning partial state and falling back to T4..."
    colab --config "$CFG" stop -s "$SESSION" >/dev/null 2>&1 || true
    GPU_TYPE="T4"
    colab --config "$CFG" new -s "$SESSION" --gpu T4
fi
echo "[gpu] Allocated $GPU_TYPE for session '$SESSION'"

run_remote() {
    local cmd="$1"
    local attempt=1
    while [ "$attempt" -le 5 ]; do
        if timeout 120 colab --config "$CFG" exec -s "$SESSION" --timeout 60 --env "CMD=$cmd" -f "$RUNNER"; then
            return 0
        fi
        echo "[warn] run_remote attempt $attempt failed for: $cmd; retrying in 8s..."
        attempt=$((attempt + 1))
        sleep 8
    done
    echo "[error] run_remote failed after 5 attempts: $cmd"
    return 1
}

run_remote "nvidia-smi && nproc && mkdir -p /content/proj_a_eegdenoise/data/raw"

tar -czf /tmp/proj_a_src.tar.gz -C "$PROJ_DIR" src
colab --config "$CFG" upload -s "$SESSION" /tmp/proj_a_src.tar.gz /content/proj_a_src.tar.gz
run_remote "tar -xzf /content/proj_a_src.tar.gz -C /content/proj_a_eegdenoise && rm -f /content/proj_a_src.tar.gz"

echo "[upload] Uploading true 512 Hz EEGdenoiseNet npy files..."
colab --config "$CFG" upload -s "$SESSION" "$PROJ_DIR/data/raw/EEG_all_epochs_512hz.npy" /content/proj_a_eegdenoise/data/raw/EEG_all_epochs_512hz.npy
colab --config "$CFG" upload -s "$SESSION" "$PROJ_DIR/data/raw/EMG_all_epochs_512hz.npy" /content/proj_a_eegdenoise/data/raw/EMG_all_epochs_512hz.npy

echo "[step] Launching resilient background pipeline on Colab..."
run_remote "rm -f /content/proj_a_bg.log /content/proj_a_bg.rc && cat <<'EOF' > /content/run_bg_a.sh
#!/usr/bin/env bash
set -euo pipefail
export PYTHONUNBUFFERED=1
python3 -u /content/proj_a_eegdenoise/src/01_download_data.py
python3 -u /content/proj_a_eegdenoise/src/02_synthesis.py
python3 -u /content/proj_a_eegdenoise/src/04_train_eval.py --epochs 70
python3 -u /content/proj_a_eegdenoise/src/05_plot_figures.py
ls -lh /content/proj_a_eegdenoise/outputs /content/proj_a_eegdenoise/outputs/figures
tar -czf /content/proj_a_outputs.tar.gz -C /content/proj_a_eegdenoise outputs
EOF
chmod +x /content/run_bg_a.sh
nohup bash -c '/content/run_bg_a.sh; echo \$? > /content/proj_a_bg.rc' > /content/proj_a_bg.log 2>&1 < /dev/null &"

printed_lines=0
while true; do
    sleep 20
    status_out=$(run_remote "python3 -c '
import os
log = \"/content/proj_a_bg.log\"
rcf = \"/content/proj_a_bg.rc\"
skip = $printed_lines
if os.path.exists(log):
    with open(log) as f:
        lines = f.readlines()
    for l in lines[skip:]:
        print(\"LOG:\" + l, end=\"\")
    print(f\"__LINES__={len(lines)}\")
else:
    print(\"__LINES__=0\")
if os.path.exists(rcf):
    print(\"__RC__=\" + open(rcf).read().strip())
'")
    while IFS= read -r line; do
        case "$line" in
            LOG:*)
                echo "${line#LOG:}"
                ;;
            __LINES__=*)
                printed_lines="${line#__LINES__=}"
                ;;
            __RC__=*)
                rc_val="${line#__RC__=}"
                echo "[remote-bg] Finished with exit code $rc_val"
                if [ "$rc_val" != "0" ]; then
                    exit "$rc_val"
                fi
                break 2
                ;;
        esac
    done <<< "$status_out"
done

echo "[download] Downloading SPEC A outputs..."
colab --config "$CFG" download -s "$SESSION" /content/proj_a_outputs.tar.gz /tmp/proj_a_outputs.tar.gz
tar -xzf /tmp/proj_a_outputs.tar.gz -C "$PROJ_DIR"

test -s "$PROJ_DIR/outputs/metrics_summary.csv"
test -s "$PROJ_DIR/outputs/REPORT_SUMMARY.md"
test -s "$PROJ_DIR/outputs/figures/fig1_snr_rrmse.png"
test -s "$PROJ_DIR/outputs/figures/fig2_waveform_psd.png"
test -s "$PROJ_DIR/outputs/figures/fig3_clean_preservation.png"

echo "GPU=$GPU_TYPE" > "$DONE_FILE"
echo "[done] SPEC A finished at $(date -Is)"
